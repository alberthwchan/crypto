# Candlestick validator

Submission for candlestick validation challenge.

Includes a main program that can be invoked to try out on the data from `api.crypto.com`, and includes unit tests for the candlestick validation functionality.

The app is built using maven and uses Java 17.

## Design

The algorithm asserts consistency between a list of trades and candlesticks, within a specified time range.
The time range specification allows us to only check a portion of time where data from both the trades list and candlesticks list is fully available.

Currently only data from `https://api.crypto.com/v2/public/get-trades` and `https://api.crypto.com/v2/public/get-candlestick`.

In addition to the spec, the algorithm makes the following assumptions:

1. All trades are present in the range that needs to be checked, and candlesticks used only and every trade in the trade array
2. When there are 0 trades in a candle's time range, the candlestick object may be ommitted from the array or have volume "0".
3. When validating a time range that begins or ends in the middle of a candle, the entire candle is evaluated and includes looking at trades outside of the range but inside the "border" candles.
4. When a candle is missing in the validating time range and there are trades in the candle's range, that is declared an error.

## Build

```
$ mvn install
$ mvn package
```


## Run Application

The application does a simple query of `api.crypto.com` for `get-trades` and `get-candlesticks`, and validates the results
in the time range that the trades appeared in (and assumes the candlesticks cover them).

```
$ mvn exec:java -Dexec.mainClass="Application"
```

You can pass it a parameter to inspect a different symbol:

```
$ mvn exec:java -Dexec.mainClass="Application" -Dexec.args="ADA_BTC"
```

## Run Tests

```
mvn test 
```
