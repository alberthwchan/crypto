import java.io.IOException;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

public class Api {
    public static final String API_BASE = "https://api.crypto.com/v2/public/";

    public static TradeData fetchTrades(String instrumentName) throws IOException, InterruptedException {
        // create a client
        var client = HttpClient.newHttpClient();

// create a request
        var request = HttpRequest.newBuilder(
                URI.create(API_BASE + "get-trades?instrument_name=" + URLEncoder.encode(instrumentName)))
                .GET()
                .header("accept", "application/json")
                .build();

// use the client to send the request

        var response = client.send(request, new JsonBodyHandler<>(TradeData.class));

// the response:
        return response.body().get();
    }


    public static CandlestickData fetchCandlesticks(String instrumentName, String timeFrame) throws IOException, InterruptedException {
        // create a client
        var client = HttpClient.newHttpClient();

// create a request
        var request = HttpRequest.newBuilder(
                URI.create(API_BASE + "get-candlestick?instrument_name=" + URLEncoder.encode(instrumentName) + "&timeframe=" + URLEncoder.encode(timeFrame)))
                .GET()
                .header("accept", "application/json")
                .build();

// use the client to send the request

        var response = client.send(request, new JsonBodyHandler<>(CandlestickData.class));

// the response:
        return response.body().get();
    }
}
