import java.io.IOException;
import java.io.UncheckedIOException;
import java.util.ArrayList;
import java.util.Date;

public class Application {
    // API for trades and combos happen at different times so allow for some fudge in consistency in recent trades.
    public static final long CHECK_FUZZ_MS = 3000;

    public static void main(String argv[]) {

        var symbol = "ADA_BTC";
        if (argv.length > 0) {
            symbol = argv[0];
        }

        System.out.println("Querying API for symbol " + symbol + "...");

        try {
            Date beforeCall = new Date();
            TradeData tradeData = Api.fetchTrades(symbol);

            CandlestickData candlestickData = Api.fetchCandlesticks(symbol, "1m");

            var trades = new ArrayList<>(tradeData.getResult().getData());
            trades.sort((a, b) -> (int)(a.getTimestamp() - b.getTimestamp()));

            var candles = new ArrayList<>(candlestickData.getResult().getData());
            candles.sort((a, b) -> (int)(a.getTimestampEnd() - b.getTimestampEnd()));

            // get earliest trade, we can only start verifying from there.
            var earliest_time = trades.get(0).getTimestamp();
            var latest_time = trades.get(trades.size() - 1).getTimestamp();

            System.out.println("Checking " + trades.size() + " trades and " + candles.size() + " candles");
            var verified = CandlestickVerifier.isConsistent(
                    trades,
                    candles,
                    earliest_time + CHECK_FUZZ_MS,
                    latest_time - CHECK_FUZZ_MS,
                    "1m",
                    true
            );
            System.out.println(verified ?
                    "Candlesticks for " + ((latest_time - earliest_time) / 1000) + "s verified" :
                    "The candlesticks for " + ((latest_time - earliest_time) / 1000) + "s range and trade data don't match"
            );

        } catch (IOException e) {
            throw new UncheckedIOException(e);
        } catch (InterruptedException e) {
            System.out.println("Interrupted!");
            System.exit(1);
        }
    }
}
