import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@JsonIgnoreProperties(ignoreUnknown = true)
public class CandlestickData {

    @JsonProperty("result")
    private CandlestickResult result;

    @Getter
    @Setter
    @JsonIgnoreProperties(ignoreUnknown = true)
    public class CandlestickResult {
        @JsonProperty("instrument_name")
        private String instrumentName;

        @JsonProperty("interval")
        private String interval;

        @JsonProperty("data")
        private List<Candlestick> data;
    }

    @Getter
    @Setter
    @AllArgsConstructor
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class Candlestick {
        @JsonProperty("t")
        private long timestampEnd;

        @JsonProperty("o")
        private double open;

        @JsonProperty("h")
        private double high;

        @JsonProperty("l")
        private double low;

        @JsonProperty("c")
        private double close;

        @JsonProperty("v")
        private double volume;

        public Candlestick() {}
    }
}
