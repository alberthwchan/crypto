import java.util.Date;
import java.util.List;

public class CandlestickVerifier {
    public static final double EPS = 1e-12;

    /**
     * Verifies the consistency of the trade data against the candlesticks between the specified time range
     * of [begin, end). Only errors like assymetric missing data or wrong prices within the time range
     * will be reported.
     *
     *
     * @param trades List of trades to verify, sorted by timestamp.
     * @param candlesticks List of candlesticks to verify, sorted by timestampEnd.
     * @param begin Start timestamp of the range to test, inclusive.
     * @param end End timestamp of the range to test, exclusive.
     * @return true if consistent, false otherwise.
     */
    public static boolean isConsistent(List<TradeData.Trade> trades, List<CandlestickData.Candlestick> candlesticks, long begin, long end, String period, boolean print) {
        // if a candle or lack thereof overlaps [begin, end) at all, it will be verified.
        var periodMs = Util.getPeriodMs(period);

        var lastVerified = begin;

        int t_i = 0;
        for (var c: candlesticks) {
            if (c.getTimestampEnd() <= begin) {
                // Don't verify candles that are not part of the range.
                System.out.println("timestamp is " + c.getTimestampEnd() + " but we begin at " + begin);
                continue;
            }
            // should we measure this candlestick?
            var candleStart = c.getTimestampEnd() - periodMs;

            // move trade cursor to start of candle.
            while (t_i < trades.size() && trades.get(t_i).getTimestamp() < candleStart) {
                if (trades.get(t_i).getTimestamp() >= begin && trades.get(t_i).getTimestamp() < end) {
                    // this trade was in range, but didn't have a candle covering it. There is a missing candle.

                    if (print) {
                        System.out.printf("Trade %d of %d: OHLC mismatch, we don't have a candle covering us.", t_i, trades.size());
                    }
                    return false;
                }
                t_i ++;
            }

            int start_t = t_i;
            var expectedHigh = Double.MIN_VALUE;
            var expectedLow = Double.MAX_VALUE;
            var expectedVolume = 0;

            // move trade cursor to end of candle.
            while (t_i < trades.size() && trades.get(t_i).getTimestamp() < c.getTimestampEnd()) {
                expectedHigh = Math.max(expectedHigh, trades.get(t_i).getPrice());
                expectedLow = Math.min(expectedLow, trades.get(t_i).getPrice());
                expectedVolume += trades.get(t_i).getQuantity();
                t_i ++;
            }

            int end_t = t_i;

            // verify candle.
            if (start_t == end_t) {
                // there were no trades in the candle.
                // The candle should not be here. But yet here it is.
                if (c.getVolume() != 0) {
                    if (print) {
                        System.out.printf("Trade %d of %d: OHLC mismatch, a candle found that has volume but had no trades at all", t_i, trades.size());
                    }
                    return false;
                }
            } else {
                var expectedOpen = trades.get(start_t).getPrice();
                var expectedClose = trades.get(end_t - 1).getPrice();

                if (!doubleEq(expectedHigh, c.getHigh()) || !doubleEq(expectedLow, c.getLow()) || !doubleEq(expectedOpen,c.getOpen()) || !doubleEq(expectedClose, c.getClose())) {
                    // OCHL mismatch
                    if (print) {
                        System.out.printf("Trade %d of %d: OHLC mismatch, expected %.12f %.12f %.12f %.12f, got %.12f %.12f %.12f %.12f\n", t_i, trades.size(), expectedOpen, expectedHigh, expectedLow, expectedClose, c.getOpen(), c.getHigh(), c.getLow(), c.getClose());
                    }
                    return false;
                }
                if (!doubleEq(expectedVolume, c.getVolume())) {
                    // Candle doesn't match in volume.
                    if (print) {
                        System.out.println("Trade " + t_i + " of " + trades.size() + ": volume mismatch, expected " + expectedVolume + " actual " + c.getVolume());
                    }
                    return false;
                }
            }


            if (candleStart >= end) {
                break;
            }
        }
        if (t_i < trades.size() && trades.get(t_i).getTimestamp() < end)  {
            // There are trades towards the end of the range that need candle(s) but there are no candles.
            if (print) {
                System.out.println("Trade " + t_i + " of " + trades.size() + ": towards end of time range but no candles cover us " + trades.get(t_i).getTimestamp() + " " + end);
            }
            return false;
        }

        return true;
    }
    public static boolean isConsistent(List<TradeData.Trade> trades, List<CandlestickData.Candlestick> candlesticks, long begin, long end, String period) {
        return isConsistent(trades, candlesticks, begin, end, period, false);
    }

    public static boolean doubleEq(double a, double b) {
        return Math.abs(a - b) <= EPS;
    }
}
