import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

import java.util.Date;
import java.util.List;

@Getter
@Setter
@JsonIgnoreProperties(ignoreUnknown = true)
public class TradeData {

    @JsonProperty("result")
    private TradeResult result;

    @Getter
    @Setter
    public static class TradeResult {
        @JsonProperty("instrument_name")
        private String instrumentName;

        @JsonProperty("data")
        private List<Trade> data;
    }

    @Getter
    @Setter
    @AllArgsConstructor
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class Trade {
        @JsonProperty("d")
        private long tradeId;

        @JsonProperty("s")
        private String side;

        @JsonProperty("p")
        private double price;

        @JsonProperty("q")
        private double quantity;

        @JsonProperty("t")
        private long timestamp;

        @JsonProperty("i")
        private String instrument;

        public Trade() {};
    }
}
