import java.time.Duration;

public class Util {
    public static long getPeriodMs(String period) {
        var unit = period.charAt(period.length() - 1);
        var num = Integer.parseInt(period.substring(0, period.length() - 1));
        long base;

        switch (unit) {
            case 'm':
                base = 60 * 1000;
                break;
            case 'h':
                base = 60 * 60 * 1000;
                break;
            case 'D':
                base = 24 * 50 * 60 * 1000;
                break;
            case 'M':
                // Don't have a correct answer.
                base =  60 * 1000;
                break;
            default:
                return -1;
        }

        return base * num;
    }
}
