import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.Collections;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;


public class CandlestickVerifierTest {
    TradeData.Trade t(long time, long price, long quantity) {
        return new TradeData.Trade(0, "BUY", price, quantity, time, "BTC_USDT");
    }

    CandlestickData.Candlestick c(long timeEnd, double open, double high, double low, double close, double volume) {
        return new CandlestickData.Candlestick(timeEnd, open, high, low, close, volume);
    }

    @BeforeEach
    void setUp() {
    }

    @Test
    @DisplayName("Should accept empty chart")
    void verifyEmptyDataTest() {
        assertTrue(CandlestickVerifier.isConsistent(Collections.emptyList(), Collections.emptyList(), 0, 360 * 1000, "1m"));
    }

    @Test
    @DisplayName("Should verify/falsify OHLC of a candle with one trade")
    void verifySingleTrade() {
        assertTrue(CandlestickVerifier.isConsistent(
                Arrays.asList(t(0, 100, 1)),
                Arrays.asList(c(60 * 1000, 100, 100, 100, 100, 1)),
                0,
                60 * 1000,
                "1m"
        ));

        assertFalse(CandlestickVerifier.isConsistent(
                Arrays.asList(t(0, 100, 1)),
                Arrays.asList(c(60 * 1000, 95, 100, 100, 100, 1)),
                0,
                60 * 1000,
                "1m"
        ));

        assertFalse(CandlestickVerifier.isConsistent(
                Arrays.asList(t(0, 100, 1)),
                Arrays.asList(c(60 * 1000, 100, 105, 100, 100, 1)),
                0,
                60 * 1000,
                "1m"
        ));
        assertFalse(CandlestickVerifier.isConsistent(
                Arrays.asList(t(0, 100, 1)),
                Arrays.asList(c(60 * 1000, 100, 100, 80, 100, 1)),
                0,
                60 * 1000,
                "1m"
        ));
        assertFalse(CandlestickVerifier.isConsistent(
                Arrays.asList(t(0, 200, 1)),
                Arrays.asList(c(60 * 1000, 100, 100, 100, 100, 1)),
                0,
                60 * 1000,
                "1m"
        ));
        assertFalse(CandlestickVerifier.isConsistent(
                Arrays.asList(t(0, 100, 2)),
                Arrays.asList(c(60 * 1000, 100, 100, 100, 100, 1)),
                0,
                60 * 1000,
                "1m"
        ));
    }


    @Test
    @DisplayName("Should verify OHLC of a candle with multiple trades")
    void verifyMultipleTrades() {
        assertTrue(CandlestickVerifier.isConsistent(
                Arrays.asList(t(0, 100, 1), t(60 * 1000 - 1, 200, 1)),
                Arrays.asList(c(60 * 1000, 100, 200, 100, 200, 2)),
                0,
                60 * 1000,
                "1m"
        ));

        assertTrue(CandlestickVerifier.isConsistent(
                Arrays.asList(t(0, 100, 1), t(30 * 1000, 20, 1), t(60 * 1000 - 1, 200, 1)),
                Arrays.asList(c(60 * 1000, 100, 200, 20, 200, 3)),
                0,
                60 * 1000,
                "1m"
        ));

        assertTrue(CandlestickVerifier.isConsistent(
                Arrays.asList(t(0, 100, 1), t(30 * 1000, 300, 1), t(60 * 1000 - 1, 200, 1)),
                Arrays.asList(c(60 * 1000, 100, 300, 100, 200, 3)),
                0,
                60 * 1000,
                "1m"
        ));

        assertTrue(CandlestickVerifier.isConsistent(
                Arrays.asList(t(0, 100, 1), t(30 * 1000, 100, 1), t(60 * 1000 - 1, 100, 1)),
                Arrays.asList(c(60 * 1000, 100, 100, 100, 100, 3)),
                0,
                60 * 1000,
                "1m"
        ));
    }

    @Test
    @DisplayName("Should verify OHLC of multiple candles")
    void verifyMultipleCandles() {
        assertTrue(CandlestickVerifier.isConsistent(
                Arrays.asList(
                        t(0, 100, 1),
                        t(60 * 1000 - 1, 200, 1),
                        t(120 * 1000 - 1, 300, 1),
                        t(180 * 1000 - 1, 400, 1)
                ),
                Arrays.asList(
                        c(60 * 1000 - 1, 100, 100, 100, 100, 1),
                        c(120 * 1000 - 1, 200, 200, 200, 200, 1),
                        c(180 * 1000 - 1, 300, 300, 300, 300, 1),
                        c(240 * 1000 - 1, 400, 400, 400, 400, 1)
                ),
                0,
                180 * 1000,
                "1m"
        ));

        assertTrue(CandlestickVerifier.isConsistent(
                Arrays.asList(
                        t(0, 100, 1),
                        t(30 * 1000, 200, 1),

                        t(60 * 1000, 150, 1),
                        t(90 * 1000, 250, 1),

                        t(120 * 1000, 300, 1),
                        t(150 * 1000, 400, 1),

                        t(180 * 1000, 450, 1),
                        t(210 * 1000, 480, 1),
                        t(220 * 1000, 320, 1),
                        t(230 * 1000, 350, 1)
                ),
                Arrays.asList(
                        c(60 * 1000, 100, 200, 100, 200, 2),
                        c(120 * 1000, 150, 250, 150, 250, 2),
                        c(180 * 1000, 300, 400, 300, 400, 2),
                        c(240 * 1000, 450, 480, 320, 350, 4)
                ),
                0,
                240 * 1000,
                "1m"
        ));
    }

    @Test
    @DisplayName("Detect when a candle is missing")
    void detectMissing() {
        assertFalse(CandlestickVerifier.isConsistent(
                Arrays.asList(
                        t(0, 100, 1),
                        t(30 * 1000, 200, 1),

                        t(60 * 1000, 150, 1),
                        t(90 * 1000, 250, 1),

                        t(120 * 1000, 300, 1),
                        t(150 * 1000, 400, 1),

                        t(180 * 1000, 450, 1),
                        t(210 * 1000, 480, 1),
                        t(220 * 1000, 320, 1),
                        t(230 * 1000, 350, 1)
                ),
                Arrays.asList(
                        c(120 * 1000, 150, 250, 150, 250, 2),
                        c(180 * 1000, 300, 400, 300, 400, 2),
                        c(240 * 1000, 450, 480, 320, 350, 4)
                ),
                0,
                240 * 1000,
                "1m"
        ));

        assertFalse(CandlestickVerifier.isConsistent(
                Arrays.asList(
                        t(0, 100, 1),
                        t(30 * 1000, 200, 1),

                        t(60 * 1000, 150, 1),
                        t(90 * 1000, 250, 1),

                        t(120 * 1000, 300, 1),
                        t(150 * 1000, 400, 1),

                        t(180 * 1000, 450, 1),
                        t(210 * 1000, 480, 1),
                        t(220 * 1000, 320, 1),
                        t(230 * 1000, 350, 1)
                ),
                Arrays.asList(
                        c(60 * 1000, 100, 200, 100, 200, 2),
                        c(180 * 1000, 300, 400, 300, 400, 2),
                        c(240 * 1000, 450, 480, 320, 350, 4)
                ),
                0,
                240 * 1000,
                "1m"
        ));

        assertFalse(CandlestickVerifier.isConsistent(
                Arrays.asList(
                        t(0, 100, 1),
                        t(30 * 1000, 200, 1),

                        t(60 * 1000, 150, 1),
                        t(90 * 1000, 250, 1),

                        t(120 * 1000, 300, 1),
                        t(150 * 1000, 400, 1),

                        t(180 * 1000, 450, 1),
                        t(210 * 1000, 480, 1),
                        t(220 * 1000, 320, 1),
                        t(230 * 1000, 350, 1)
                ),
                Arrays.asList(
                        c(60 * 1000, 100, 200, 100, 200, 2),
                        c(120 * 1000, 150, 250, 150, 250, 2),
                        c(240 * 1000, 450, 480, 320, 350, 4)
                ),
                0,
                240 * 1000,
                "1m"
        ));

        assertFalse(CandlestickVerifier.isConsistent(
                Arrays.asList(
                        t(0, 100, 1),
                        t(30 * 1000, 200, 1),

                        t(60 * 1000, 150, 1),
                        t(90 * 1000, 250, 1),

                        t(120 * 1000, 300, 1),
                        t(150 * 1000, 400, 1),

                        t(180 * 1000, 450, 1),
                        t(210 * 1000, 480, 1),
                        t(220 * 1000, 320, 1),
                        t(230 * 1000, 350, 1)
                ),
                Arrays.asList(
                        c(60 * 1000, 100, 200, 100, 200, 2),
                        c(120 * 1000, 150, 250, 150, 250, 2),
                        c(180 * 1000, 300, 400, 300, 400, 2)
                ),
                0,
                240 * 1000,
                "1m"
        ));
    }

    @Test
    @DisplayName("Check for candles that are partially in range, but check those candles entirely.")
    void checkPartialInRange() {
        assertTrue(CandlestickVerifier.isConsistent(
                Arrays.asList(
                        t(0, 100, 1),
                        t(30 * 1000, 200, 1),

                        t(60 * 1000, 150, 1),
                        t(90 * 1000, 250, 1),

                        t(120 * 1000, 300, 1),
                        t(150 * 1000, 400, 1),

                        t(180 * 1000, 450, 1),
                        t(210 * 1000, 480, 1),
                        t(220 * 1000, 320, 1),
                        t(230 * 1000, 350, 1)
                ),
                Arrays.asList(
                        c(60 * 1000, 100, 200, 100, 200, 2),
                        c(120 * 1000, 150, 250, 150, 250, 2),
                        c(180 * 1000, 300, 400, 300, 400, 2),
                        c(240 * 1000, 450, 480, 320, 350, 4)
                ),
                50 * 1000,
                190 * 1000,
                "1m"
        ));
    }
    
    @Test
    @DisplayName("Disregard checking candles and trade coverage outside of the requested checking range.")
    void disregardOutsideRange() {
        // First verify that this fails (pay attention to first candlestick, and that our last is missing)
        assertTrue(CandlestickVerifier.isConsistent(
                Arrays.asList(
                        t(0, 100, 1),
                        t(30 * 1000, 200, 1),

                        t(60 * 1000, 150, 1),
                        t(90 * 1000, 250, 1),

                        t(120 * 1000, 300, 1),
                        t(150 * 1000, 400, 1),

                        t(180 * 1000, 450, 1),
                        t(210 * 1000, 480, 1),
                        t(220 * 1000, 320, 1),
                        t(230 * 1000, 350, 1)
                ),
                Arrays.asList(
                        c(60 * 1000, 100, 2000, 1000, 2000, 4),
                        c(120 * 1000, 150, 250, 150, 250, 2),
                        c(180 * 1000, 300, 400, 300, 400, 2)
                ),
                60 * 1000,
                180 * 1000,
                "1m"
        ));

        // Now it should work if we shorten our range.
        assertTrue(CandlestickVerifier.isConsistent(
                Arrays.asList(
                        t(0, 100, 1),
                        t(30 * 1000, 200, 1),

                        t(60 * 1000, 150, 1),
                        t(90 * 1000, 250, 1),

                        t(120 * 1000, 300, 1),
                        t(150 * 1000, 400, 1),

                        t(180 * 1000, 450, 1),
                        t(210 * 1000, 480, 1),
                        t(220 * 1000, 320, 1),
                        t(230 * 1000, 350, 1)
                ),
                Arrays.asList(
                        c(60 * 1000, 100, 2000, 1000, 2000, 4),
                        c(120 * 1000, 150, 250, 150, 250, 2),
                        c(180 * 1000, 300, 400, 300, 400, 2)
                ),
                60 * 1000,
                180 * 1000,
                "1m"
        ));
    }
}
